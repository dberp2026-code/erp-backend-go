package main

import ("encoding/json"; "log"; "net/http"; "time"; "fmt")

func ApiHandler(w http.ResponseWriter, r *http.Request) {
   w.Header().Set("Content-Type", "application/json")
   // Recuperación global de panics para esta petición
   defer func() {
      if rec := recover(); rec != nil {
         log.Printf("[PANIC RECOVER]: %v", rec)
         w.WriteHeader(http.StatusInternalServerError)
         json.NewEncoder(w).Encode(map[string]string {
            "ERROR": fmt.Sprintf("Error interno del servidor: %v", rec),
         })
      }
    }()   
   if r.Method != http.MethodPost {
      w.WriteHeader(http.StatusMethodNotAllowed)
      json.NewEncoder(w).Encode(map[string]string{"error": "Método no permitido"})
      return
   }
   var laData map[string]any
   if err := json.NewDecoder(r.Body).Decode(&laData); err != nil {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"error": "JSON de entrada inválido"})
      return
   }
   id, ok := laData["ID"].(string)
   if !ok || id == "" {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"error": "ID no definido"})
      return
   }
   fmt.Println("ID:", id, "-", time.Now().Format("2006-01-02 15:04:05.00"))
   // Mesa de Partes
   if id[:3] == "MPV" {
      HMesaPartes(w, r, laData)
      fmt.Println(time.Now().Format("2006-01-02 15:04:05.00"))
      return // Salimos para que finalice la ejecución
   }   
   var lcRpta string
   var err error
   if id == "LOGIN" {
      ltInicio := time.Now()
      lo := SLogin{Data: laData}
      lcRpta, err = lo.omLogin()
      fmt.Println("Tiempo transcurrido:", time.Since(ltInicio))
   } else if id == "CLAVE" {
      lo := SClave{Data: laData}
      lcRpta, err = lo.omCifrarClave()
   } else if id == "CLAVE1" {
      lo := SClave{Data: laData}
      lcRpta, err = lo.omCompararClave()
   } else if id == "CLAVE9" {
      ltInicio := time.Now()
      lo := SClave{Data: laData}
      err = lo.omActualizarClaves()
      fmt.Println("Tiempo transcurrido:", time.Since(ltInicio))
   } else {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"ERROR": "ID no reconocido"})
      return
   }
   if err != nil {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"ERROR": err.Error()})
      return
   }
   w.WriteHeader(http.StatusOK)
   w.Write([]byte(lcRpta))
}

/*
func ApiHandler_old(w http.ResponseWriter, r *http.Request) {
   w.Header().Set("Content-Type", "application/json")

   if r.Method != http.MethodPost {
      w.WriteHeader(http.StatusMethodNotAllowed)
      json.NewEncoder(w).Encode(map[string]string{"error": "Método no permitido"})
      return
   }

   var datosEntrada map[string]any
   if err := json.NewDecoder(r.Body).Decode(&datosEntrada); err != nil {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"error": "JSON de entrada inválido"})
      return
   }

   id, ok := datosEntrada["ID"].(string)
   if !ok || id == "" {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"error": "ID no definido"})
      return
   }

   var resultadoJSON string
   var err error

   if id == "LOGIN" {
      loginService := SLogin{Datos: datosEntrada}
      resultadoJSON, err = loginService.omLogin()
   } else if id == "CLAVE" {
      claveService := SClave{Datos: datosEntrada}
      resultadoJSON, err = claveService.omCifrarClave()
   } else {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"error": "ID no reconocido"})
      return
   }
   if err != nil {
      w.WriteHeader(http.StatusBadRequest)
      json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
      return
   }
   w.WriteHeader(http.StatusOK)
   w.Write([]byte(resultadoJSON))
}
*/

func main() {
   if err := ConnectDB(); err != nil {
      log.Fatalf("No se pudo conectar a la BD: %v", err)
   }
   defer poPool.Close()
   http.HandleFunc("/", ApiHandler)
   log.Println("Servidor API REST escuchando en http://localhost:8080")
   if err := http.ListenAndServe(":8080", nil); err != nil {
      log.Fatalf("Error en el servidor: %v", err)
   }
}