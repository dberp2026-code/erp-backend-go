package main

import ("context"; "log"; "time"; "github.com/jackc/pgx/v5/pgxpool")

var poPool *pgxpool.Pool

func ConnectDB() error {
   laConfig, err := pgxpool.ParseConfig("postgres://postgres:postgres@localhost:5432/DB_ERP?sslmode=disable")
   if err != nil {
      return err
   }
   laConfig.MaxConns = 25
   laConfig.MinConns = 5
   laConfig.MaxConnLifetime = 5 * time.Minute
   laConfig.MaxConnIdleTime = 2 * time.Minute
   poPool, err = pgxpool.NewWithConfig(context.Background(), laConfig)
   if err != nil {
      return err
   }
   if err := poPool.Ping(context.Background()); err != nil {
      return err
   }
   log.Println("Conectado a la base de datos")
   return nil
}